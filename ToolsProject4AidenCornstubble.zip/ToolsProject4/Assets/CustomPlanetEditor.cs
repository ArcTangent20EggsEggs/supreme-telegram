﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System;

[CustomEditor(typeof(PlanetBase))]
public class CustomPlanetEditor : Editor
{
    PlanetBase jeff;
    private SerializedObject bill;
    private SerializedProperty bob;
    
    void OnEnable()
    {
        jeff = (PlanetBase)target;
        bill = new SerializedObject(target);
    }

    public override void OnInspectorGUI()
    {
        DrawBasicInfo();
        //base.OnInspectorGUI();
    }

    public void DrawBasicInfo()
    {
        bob = bill.FindProperty("mainElements");
        EditorGUILayout.LabelField("Planet Info", EditorStyles.boldLabel);
        EditorGUILayout.BeginVertical("button");
        jeff.mainColor = EditorGUILayout.ColorField("Planet Color: ", jeff.mainColor);
        jeff.hasWater = EditorGUILayout.Toggle("Does This Planet Have Water?", jeff.hasWater);
        EditorGUILayout.MinMaxSlider(ref jeff.lowTemp, ref jeff.highTemp, -273.15f, 500f);
        EditorGUILayout.BeginVertical("button");
        GUILayout.Space(10);
        jeff.lowTemp = Mathf.Min(Mathf.Max( EditorGUILayout.FloatField("Planet Low Temperature in Celsius:", jeff.lowTemp), -273.15f), jeff.highTemp);
        jeff.highTemp = Mathf.Max(Mathf.Min( EditorGUILayout.FloatField("Planet High Temperature in Celsius:", jeff.highTemp), 500), jeff.lowTemp);
        EditorGUILayout.EndVertical();
        jeff.revolutionTime = Mathf.Max(EditorGUILayout.FloatField(new GUIContent("Revolution Time: ", "EX: 24 hours"), jeff.revolutionTime), 0);
        jeff.isHabitable = EditorGUILayout.Toggle(new GUIContent("Is the Planet Inhabitable?", "Can the Planet Support Natural Life?"), jeff.isHabitable);
        if(jeff.isHabitable)
        {
            EditorGUILayout.BeginHorizontal("box");
            GUILayout.Space(10);
            jeff.flora = EditorGUILayout.Toggle(new GUIContent("Does the Planet Have Plants?", "Nessecary For the Planet to have animals"), jeff.flora);
            EditorGUILayout.EndHorizontal();
            if (jeff.flora)
            {
                EditorGUILayout.BeginHorizontal("button");
                GUILayout.Space(20);
                jeff.fauna = EditorGUILayout.Toggle("Does the Planet Have Animals?", jeff.fauna);
                EditorGUILayout.EndHorizontal();
            }
            else
            {
                jeff.fauna = false;
            }
        }
        else
        {
            jeff.flora = false;
            jeff.fauna = false;
        }
        jeff.moonAmount = EditorGUILayout.IntField("How Many Moons Does the Planet Have?", jeff.moonAmount);
        if(jeff.moonAmount < 0)
        {
            jeff.moonAmount = 0;
        }
        jeff.orbitTime = Mathf.Max(EditorGUILayout.FloatField(new GUIContent("How Long Does the Planet Take to Orbit: ", "The Planet's Year Length EX: 365 Days"), jeff.orbitTime), 0.1f);
        EditorGUILayout.MinMaxSlider(ref jeff.lowElevation, ref jeff.highElevation, -1000f, 100f);
        EditorGUILayout.BeginVertical("button");
        GUILayout.Space(10);
        jeff.lowElevation = Mathf.Min(Mathf.Max(EditorGUILayout.FloatField("Planet's Lowest Elevation in Miles:", jeff.lowElevation), -1000), jeff.highElevation);
        jeff.highElevation = Mathf.Max(Mathf.Min(EditorGUILayout.FloatField("Planet's Highest Elevation in Miles:", jeff.highElevation), 100), jeff.lowElevation);
        EditorGUILayout.EndVertical();
        jeff.planetSize = EditorGUILayout.IntField(new GUIContent("Radius of the Planet in Miles", "EX Earth's Radius is 3,959 Miles"), jeff.planetSize);
        if(jeff.planetSize < 1)
        {
            jeff.planetSize = 1;
        }
        jeff.radiationAmount = Mathf.Max(EditorGUILayout.FloatField("The Radiation Amount of the Planet Measured in Rads", jeff.radiationAmount), 0);
        jeff.isHabitable = EditorGUILayout.Toggle("Does the Planet Have Intelegent Creatures, Native or Otherwise?", jeff.isHabitable);
        if(jeff.isHabitable)
        {
            EditorGUILayout.BeginHorizontal("box");
            GUILayout.Space(10);
            jeff.icPopulation = EditorGUILayout.IntField("How Many Intelegent Creatures are on the Planet", jeff.icPopulation);
            if(jeff.icPopulation < 0)
            {
                jeff.icPopulation = 0;
            }
            EditorGUILayout.EndHorizontal();
        }
        else
        {
            jeff.icPopulation = 0;
        }
        EditorGUILayout.PropertyField(bob, new GUIContent("The Elements that the Planet Contains"), true);
        bill.ApplyModifiedProperties();
        EditorGUILayout.EndVertical();
    }
}